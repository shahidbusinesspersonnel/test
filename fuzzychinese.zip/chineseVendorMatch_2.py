﻿#-*- coding=utf-8 -*-

import pandas as pd
from fuzzychinese import FuzzyChineseMatch
import xlrd
import json
import base64
import sys



THRESOLD = 90

def trainModelFromVendorMaster(fcm, book):
    sheet = book.sheet_by_name("Sheet1")
    vendorList = []
    print("===========VENDOR ID   VENDOR NAME FROM MASTER DATA FILE")
    for r in range(1, sheet.nrows):
        vendorList.append(sheet.cell(r,3).value)
        
        # print(int(sheet.cell(r,0).value),  "   ",sheet.cell(r,3).value)
    print("===========END OF MASTER DATA FILE")
    fcm.fit(vendorList)

def getScroeAndIndex(fcm, input):
    simlarName = fcm.transform(input, n=1)
    score = fcm.get_similarity_score()
    print('Score=', score)
    index = fcm.get_index()
    return score[0][0], index[0][0], simlarName

def getVendorID(index, book):
    sheet = book.sheet_by_name("Sheet1")
    return int(sheet.cell(index+1,0).value)


def getVendorDetails(vendorName):
    inPutVendorName = []
    inPutVendorName.append(vendorName)
    
    # print(inPutVendorName)
    #inPutVendorName =['天津韩城金属有限公司']
    print('Input Vendor Name=', inPutVendorName)
    fcm = FuzzyChineseMatch(ngram_range=(3, 3), analyzer='stroke')
    # book = xlrd.open_workbook("D:\RPA_Project\Pre-check\hanon\vendorMaster.xls")
    book = xlrd.open_workbook("vendorMaster.xls")
    trainModelFromVendorMaster(fcm, book)
    score, index, matchedName = getScroeAndIndex(fcm, inPutVendorName)
    #print('matchedName', matchedName)
    result = {}
    vendorId = None
    if score is not None:
        if score*100 > THRESOLD:
            vendorId = getVendorID(index, book)
    if vendorId is not None:
        result["status"] = "SUCCESS"
        result["vendorId"] = vendorId
        result["match_score"] = score
        # result["matchedName"] = matchedName
    else:
        result["status"] = "FAILED"
    print("Comparisn results:=====")
    print(json.dumps(result))
    return json.dumps(result)

if __name__ == "__main__":
    getVendorDetails('天津韩城金属有限公司')



